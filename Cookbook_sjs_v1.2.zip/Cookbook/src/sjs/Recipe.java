package sjs;
import java.sql.*;
import java.awt.Image;
import java.util.ArrayList;


/**
 * 
 * @author Administrator
 *@param 
 */
public class Recipe {

	int recipe_id;
	String name;
	String type;
	long save_time;
	int pre_time;
	int cook_time;
	int serve;
	Image img;
	int popular;

	ArrayList<Ingredient> ingredientList = new ArrayList<Ingredient>();  
	ArrayList<String> preparationList = new ArrayList<String>(); 
	
	/**
	 * constructor
	 */
	public Recipe() {
		this.recipe_id = -1;
		this.name = null;
		this.type=null;
		this.save_time = 0;
		this.pre_time = 0;
		this.cook_time = 0;
		this.serve = 0;
		this.img = null;
		this.popular = 0;
	}

	public Recipe(String name, String type, int serve) {
		this.name = name;
		this.type = type;
		this.serve = serve;
	}
	
	/**
	 * add ingredient into ingredientList
	 * @param ingredient
	 */
	public  void addIngredient(Ingredient ingredient) {
		 ingredientList.add(ingredient);  
	}
	
	/**
	 * add preparationStep into preparationList
	 * @param string
	 */
	public void addPreparationStep(String string) {
		preparationList.add(string);  
	}
	
	public void setPreparationTime(int time) {
		this.pre_time=time;
	}
	
	public void setCookingTime(int time) {
		this.cook_time=time;
	}
	
	/**
	 * getters and setters
	 * @return
	 */
	public int getRecipe_id() {
		return recipe_id;
	}

	public void setRecipe_id(int recipe_id) {
		this.recipe_id = recipe_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	

	public long getSave_time() {
		return save_time;
	}

	public void setSave_time(long save_time) {
		this.save_time = save_time;
	}

	public int getPre_time() {
		return pre_time;
	}

	public void setPre_time(int pre_time) {
		this.pre_time = pre_time;
	}

	public int getCook_time() {
		return cook_time;
	}

	public void setCook_time(int cook_time) {
		this.cook_time = cook_time;
	}

	public int getServe() {
		return serve;
	}

	public void setServe(int serve) {
		this.serve = serve;
	}

	public Image getImg() {
		return img;
	}

	public void setImg(Image img) {
		this.img = img;
	}

	public int getPopular() {
		return popular;
	}

	public void setPopular(int popular) {
		this.popular = popular;
	}

	public void editIns() {

	}

	public void editIng() {

	}

	public void editRec() {

	}

}

