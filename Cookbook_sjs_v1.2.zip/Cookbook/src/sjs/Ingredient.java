package sjs;

public class Ingredient {

	int int_ID;
	String ing_name;
	double amount;
	String unit;
	String ing_detail;
	
	public Ingredient() {
		this.int_ID=0;
		this.ing_name=null;
		this.amount=0;
		this.unit=null;
		this.ing_detail=null;
	}
	public Ingredient(String name, double amount, String unit) {
		this.ing_name=name;
		this.amount=amount;
		this.unit=unit;
	}

	public Ingredient(String name, double amount, String unit, String ing_detail) {
		this.ing_name=name;
		this.amount=amount;
		this.unit=unit;
		this.ing_detail=ing_detail;
	}
	
}
