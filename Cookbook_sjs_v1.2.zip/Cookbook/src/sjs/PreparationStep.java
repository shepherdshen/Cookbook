package sjs;

public class PreparationStep {

	int step_id;
	String step_name;
	
	public PreparationStep() {
		this.step_id=0;
		this.step_name=null;
	}

	public PreparationStep(String string) {
		this.step_name=string;
	}
	
}
